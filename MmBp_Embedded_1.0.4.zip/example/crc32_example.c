//  crc32_example.c
//  WeChat Embedded
//
//  Created by harlliu on 14-03-12.
//  Copyright 2014 Tencent. All rights reserved.
//

#include <stdio.h>
#include <stdint.h>
#include "crc32.h"

int main(int argc, char **argv)
{
	uint8_t data[] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09};

	uint32_t crc = crc32(0, data, sizeof(data));
	printf("0x%08x\n", crc); //0x40efab9e

	return 0;
}
